<?php
// created: 2014-01-29 09:59:23
$unified_search_modules_display = array (
  'AOP_Case_Events' => 
  array (
    'visible' => false,
  ),
  'AOP_Case_Updates' => 
  array (
    'visible' => false,
  ),
  'AOR_Reports' => 
  array (
    'visible' => false,
  ),
  'AOS_Contracts' => 
  array (
    'visible' => false,
  ),
  'AOS_Invoices' => 
  array (
    'visible' => false,
  ),
  'AOS_PDF_Templates' => 
  array (
    'visible' => false,
  ),
  'AOS_Product_Categories' => 
  array (
    'visible' => false,
  ),
  'AOS_Products' => 
  array (
    'visible' => false,
  ),
  'AOS_Quotes' => 
  array (
    'visible' => false,
  ),
  'AOW_Processed' => 
  array (
    'visible' => false,
  ),
  'AOW_WorkFlow' => 
  array (
    'visible' => false,
  ),
  'Accounts' => 
  array (
    'visible' => true,
  ),
  'Bugs' => 
  array (
    'visible' => false,
  ),
  'Calls' => 
  array (
    'visible' => true,
  ),
  'Calls_Reschedule' => 
  array (
    'visible' => false,
  ),
  'Campaigns' => 
  array (
    'visible' => false,
  ),
  'Cases' => 
  array (
    'visible' => true,
  ),
  'Contacts' => 
  array (
    'visible' => true,
  ),
  'Documents' => 
  array (
    'visible' => true,
  ),
  'FP_Event_Locations' => 
  array (
    'visible' => false,
  ),
  'FP_events' => 
  array (
    'visible' => false,
  ),
  'Leads' => 
  array (
    'visible' => true,
  ),
  'Meetings' => 
  array (
    'visible' => true,
  ),
  'Notes' => 
  array (
    'visible' => true,
  ),
  'Opportunities' => 
  array (
    'visible' => true,
  ),
  'Project' => 
  array (
    'visible' => false,
  ),
  'ProjectTask' => 
  array (
    'visible' => false,
  ),
  'ProspectLists' => 
  array (
    'visible' => false,
  ),
  'Prospects' => 
  array (
    'visible' => false,
  ),
  'Tasks' => 
  array (
    'visible' => false,
  ),
  'jjwg_Address_Cache' => 
  array (
    'visible' => false,
  ),
  'jjwg_Areas' => 
  array (
    'visible' => false,
  ),
  'jjwg_Maps' => 
  array (
    'visible' => false,
  ),
  'jjwg_Markers' => 
  array (
    'visible' => false,
  ),
);